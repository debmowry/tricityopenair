<?php
/**
 * None Content Template
 * This template is used for displaying message: "No posts found".
 *
 * @package WordPress
 * @subpackage WPstart
 */
?>

<?php do_action('wpstart_entry_before'); ?>

	<?php do_action('wpstart_entry_no_results_not_found'); ?>

<?php do_action('wpstart_entry_after'); ?>