=== Maisha Lite ===
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

"Maisha Lite" is a lite & free version of beautiful charity WordPress theme "Maisha". Theme is inspired by "Virunga" documentary. It is modern, responsive and mobile friendly theme.

== Description ==
* documentation link: http://www.anarieldesign.com/documentation/maishalite/

== Credits ==
1. Genericons: http://genericons.com/ - license is included inside the “genericons” folder
2. Google Fonts: Raleway: https://www.google.com/fonts/specimen/Raleway - SIL Open Font License, 1.1 and 
Images and icons used in the live demo are just for the presentation purpose:
3. Three Line Badges in the theme screenshot can be bought here: https://creativemarket.com/buildinteractive/179532-Line-Badges-Volume-2 
4. Logo image used in the screenshot can be bought on Graphicriver: http://graphicriver.net/item/wildlife-icons/4491390 
5. Free top image used for theme screenshot is made by Luca Zanon and you can download it here: https://unsplash.com/
6. This theme is based on Underscores: http://underscores.me/ - License: Distributed under the terms of the GNU GPL - Copyright: Automattic, automattic.com