== Theme: InDreams Theme ==

* By InDreams, http://www.themes.t15.org/

== Theme License & Copyright ==
InDreams Theme is distributed under the terms of the GNU GPL
InDreams Theme - Copyright 2014 InDreams Theme, themes.t15.org

License and resources links for images:
---------------------------------------
All images are created by InDreams and 
all images licensed under GPL.

1. Image Name: bg.jpg
   This image is taken from my camera when I was in trip. I have included this image with GPL license. 

License and resources links for js bundled:
-------------------------------------------
1. Bootstrap v3.0.3
    Copyright 2013 Twitter, Inc
    Licensed under the Apache License v2.0
    http://www.apache.org/licenses/LICENSE-2.0

2. jQuery FlexSlider
    jQuery FlexSlider v2.2.2
    Copyright 2012 WooThemes
    licensed under GPL and MIT

3. jQuery.meanmenu.js | GPL
    jQuery meanmenu v2.0.8
    Copyright (C) 2012-2014 Chris Wharton @ MeanThemes (https://github.com/meanthemes/meanMenu)
    Dual licensed under the MIT and GPL licenses.

4. jQuery Superfish Menu Plugin - v1.7.4
    Copyright (c) 2013 Joel Birch
    Dual licensed under the MIT and GPL licenses:
    http://www.opensource.org/licenses/mit-license.php
    http://www.gnu.org/licenses/gpl.html
	
5. prettyPhoto.js
    prettyPhoto.js v3.1.5
    Dual licensed under the MIT and GPL licenses.

6. Google Fonts
    Oxygen Font https://www.google.com/fonts/specimen/Arvo
    License: Distributed under SIL Open Font License, 1.1 (Open font license) 