<form role="search" method="get" class="searchform" action="<?php echo home_url('/'); ?>">
    <div>
        <label class="search">Search: </label>
        <input type="text" placeholder="Search" name="s" id="search" />
        <input type="submit" id="searchsubmit" value="" />
    </div>
</form>
<div class="clear"></div>
<br/>
